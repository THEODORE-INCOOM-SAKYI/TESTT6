const express = require('express');
const bcrypt = require('bcrypt');
const helmet = require('helmet');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();


app.use(helmet());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');


app.use(
  session({
    secret: 'your_secret_key', 
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }, 
  })
);


const users = {};


app.get('/', (req, res) => res.redirect('/login'));


app
  .route('/register')
  .get((req, res) => res.render('register', { error: '', success: '' }))
  .post(async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.render('register', { error: 'All fields are required', success: '' });
    }
    if (users[username]) {
      return res.render('register', { error: 'User already exists', success: '' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    users[username] = { password: hashedPassword };
    res.render('register', { error: '', success: 'Registration successful' });
  });


app
  .route('/login')
  .get((req, res) => res.render('login', { error: '' }))
  .post(async (req, res) => {
    const { username, password } = req.body;
    const user = users[username];
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.render('login', { error: 'Invalid credentials' });
    }
    req.session.user = username;
    res.redirect('/dashboard');
  });


app.get('/dashboard', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  res.render('dashboard', { username: req.session.user });
});


app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).send('Error logging out');
    }
    res.redirect('/login');
  });
});


app.use((req, res) => {
  res.status(404).render('error', { message: 'Page Not Found' });
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
